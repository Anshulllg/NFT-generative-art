How to use: 

step 1: run **npm install**

step2: run **npm run build**
